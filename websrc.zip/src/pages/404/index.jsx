import React from 'react'
import _404 from './img/404.png'
export default function index() {
  return (
    <div style={{height:'80vh'}} className='text-center'>
      <img src={_404}  style={{height:'100%'}}></img>
    </div>
  )
}
