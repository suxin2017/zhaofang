export default {
    qwe:'123',
}